# -*- coding: utf-8 -*-
"""
Created on Thu Sep 30 11:42:14 2021

@author: Alicia
"""

from app import app
app.run(debug = False, port = 80, host='0.0.0.0')

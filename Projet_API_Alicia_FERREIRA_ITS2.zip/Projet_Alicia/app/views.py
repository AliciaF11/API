# -*- coding: utf-8 -*-
"""
Created on Thu Sep 30 11:11:03 2021

@author: Alicia
"""

#Pour afficher une page web:

from app import app
from flask import render_template
from flask import request

import sqlite3



@app.route('/page', methods = ['POST'])
def authentification():
    if request.method == 'POST':
        login = request.form['login']
        pswd = request.form['pswd']
        user = {"login":login,"pswd":pswd} 
        
        if login=="Eric" and pswd=="eric":
            return render_template('liste.html', title='Espace professionnel', utilisateur=user)

        else:
            with sqlite3.connect("API_BD.db") as con:
                cur = con.cursor()
            res= cur.execute("SELECT* FROM cancer where Login= ?;", [login])
            rows = res.fetchall(); 
            print(rows)
            print(rows[0][17])
            user={"Id": rows[0][0], "Gender":rows[0][1], "Age": rows[0][2], "Yellow_fingers": rows[0][3], "Anxiety": rows[0][4], "Fatigue": rows[0][5], "Allergy": rows[0][6], "Respiration": rows[0][7], "Alcool": rows[0][8], "Toux":rows[0][9], "Smoking":rows[0][10], "Chronic_disease": rows[0][11], "Essouflement":rows[0][12], "Avaler":rows[0][13],"Douleur_thoracique":rows[0][14], "Cancer_des_poumons":rows[0][15], "Login":rows[0][16], "Fonction": rows[0][18], "pswd": rows[0][17]}
            if rows: 
                if rows[0][17]==pswd:
                    return render_template('action.html', title='Espace Patient', utilisateur=user)
                else:
                    return render_template('erreur.html', title='Erreur', utilisateur=user)
            con.close()
            
@app.route('/')
def index():
    user={'name' : 'Alicia', 'surname':'FERREIRA'}
    return render_template('choix.html', title='POST', utilisateur=user)
           

  
@app.route('/choix1', methods = ['POST'])
def choix1():
      return render_template('index.html')


@app.route('/choix2', methods = ['POST'])
def choix2():
      return render_template('médecin.html')
  


@app.route('/deconnexion', methods = ['POST'])
def deconnect():
    return render_template("choix.html")

@app.route('/barre', methods = ['POST'])
def barre():
    if request.method == 'POST':        
       
        if 'recherche' in request.form:     
            id= request.form['recherche']
            with sqlite3.connect("API_BD.db") as con:
                cur = con.cursor()
                cur.execute("SELECT * from cancer WHERE id=?;", [id])
                con.commit()
                rows = cur.fetchall();
                user={"Id": rows[0][0], "Gender":rows[0][1], "Age": rows[0][2], "Yellow_fingers": rows[0][3], "Anxiety": rows[0][4], "Fatigue": rows[0][5], "Allergy": rows[0][6], "Respiration": rows[0][7], "Alcool": rows[0][8], "Toux":rows[0][9], "Smoking":rows[0][10], "Chronic_disease": rows[0][11], "Essouflement":rows[0][12], "Avaler":rows[0][13],"Douleur_thoracique":rows[0][14], "Cancer_des_poumons":rows[0][15], "Login":rows[0][16], "Fonction": rows[0][18],"pswd":rows[0][17]}
                return render_template('action.html', title='Espace Patient', utilisateur=user)

